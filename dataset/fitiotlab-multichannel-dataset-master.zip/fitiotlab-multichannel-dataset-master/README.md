# fitiotlab-multichannel-dataset
Packet delivery statistics during 1.5 hours for 267 links (FIT Iot-Lab)

first column is the Distance between two nodes (0.6)
Then we have tuples of three numbers
The first value is the channel of communication
ASN of the transmission
Successful or Non of the transmission (1 or 0)

267 links / experiments of 1 hour and 30 minutes. These experiments took place in FIT IoT-LAB in Grenoble site.
Distances from 0.6 to 16.8 meters
Channels are 11 to 26
30 ms each ASN, each timeslot
Each transmission we have every 3 minutes (180 sec)
